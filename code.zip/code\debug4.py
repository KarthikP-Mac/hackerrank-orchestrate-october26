"""Check what evidence_01 and evidence_03 are and what they contain."""
import csv, json

def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

manifest = {r["file_id"]: r for r in load_csv("dataset/evidence_files.csv")}

# Check specific evidence files that are referenced in expected output
for fid in ["evidence_01", "evidence_03", "evidence_58"]:
    entry = manifest.get(fid, {})
    print(f"\n{fid}: path={entry.get('file_path')} captured_at={entry.get('captured_at')}")

# Look at evidence_01 content
from pathlib import Path
for fid in ["evidence_01", "evidence_03", "evidence_58"]:
    entry = manifest.get(fid, {})
    fp = Path("dataset") / entry.get("file_path", "")
    if fp.exists():
        ext = fp.suffix.lower()
        print(f"\n=== {fid} ({ext}) ===")
        if ext in (".json", ".log", ".txt", ".sql"):
            content = fp.read_text(encoding="utf-8", errors="ignore")
            # Find mentions of user_07, user_32, priya, novak
            for keyword in ["user_07", "user_32", "priya.raman", "novak.tomasz", "support_001", "search_052", "analytics_2034", "data_flow_9522", "evidence_58", "evidence_01", "evidence_03"]:
                if keyword.lower() in content.lower():
                    idx = content.lower().find(keyword.lower())
                    print(f"  FOUND '{keyword}' at char {idx}: ...{content[max(0,idx-50):idx+100]}...")
            print(f"  File length: {len(content)} chars")
        elif ext in (".pdf", ".png"):
            print(f"  Binary file, size={fp.stat().st_size} bytes")
    else:
        print(f"\n{fid}: FILE NOT FOUND at {fp}")
