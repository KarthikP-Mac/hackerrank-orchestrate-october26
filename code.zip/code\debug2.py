"""Debug support_ticket data for specific cases."""
import csv, json, sys
sys.path.insert(0, 'code')

def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

import importlib.util
spec = importlib.util.spec_from_file_location("main", "code/main.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

rules = {r["data_category"]: r["required_action"] for r in load_csv("dataset/deletion_rules.csv")}
identities = {r["user_id"]: r for r in load_csv("dataset/user_identities.csv")}
audit_log = load_csv("dataset/user_audit_log.csv")
manifest = load_csv("dataset/evidence_files.csv")
activity_rows = load_csv("dataset/system_activity.csv")

store = m.EvidenceStore(manifest)
store.build_index()

sample_cases = {r["case_id"]: r for r in load_csv("dataset/sample_deletion_requests.csv")}

for cid in ["case_26", "case_27", "case_28"]:
    case = sample_cases[cid]
    uid, emails, phones = m.resolve_user(case["email"], identities, audit_log)
    recs = store.find_for_user(uid, emails, phones, case["audit_at"])
    print(f"\n=== {cid} ===")
    for rec in recs:
        rtype = rec.get("type", "")
        if rtype == "support_ticket":
            print(f"  SUPPORT TICKET raw: {json.dumps(rec.get('raw', {}), indent=2)[:500]}")
            print(f"  pii={m.has_pii(rec, emails)}")

# Also check case_25
case = sample_cases.get("case_25")
if case:
    print(f"\n=== case_25 ===")
    print(f"  text: {case['request_text']}")
    print(f"  is_deletion: {m.is_deletion_request(case['request_text'])}")

# Deletion rules
print("\n=== Deletion Rules ===")
for row in load_csv("dataset/deletion_rules.csv"):
    print(f"  {row['data_category']}: {row['required_action']}")
