"""Investigate specific SQL files for failing cases."""
import sqlite3, csv
from pathlib import Path

def load_csv(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

identities = {r['user_id']: r for r in load_csv('dataset/user_identities.csv')}
audit_log = load_csv('dataset/user_audit_log.csv')

def resolve(email):
    email_norm = email.strip().lower()
    uid = None
    for uid_, row in identities.items():
        if row.get('email', '').strip().lower() == email_norm:
            uid = uid_
            break
    if uid is None:
        for entry in audit_log:
            if entry.get('field_name') == 'email':
                if (entry.get('old_value') or '').strip().lower() == email_norm:
                    uid = entry['user_id']
                    break
    return uid

# case_09: k.appiah88@gmail.com -> user_61 -> evidence_93
print("=== case_09: customer_data_inventory_20260916.sql ===")
sql_path = Path("dataset/evidence/databases/customer_data_inventory_20260916.sql")
uid = resolve('k.appiah88@gmail.com')
print(f"uid={uid}")
sql = sql_path.read_text(encoding='utf-8', errors='ignore')
conn = sqlite3.connect(':memory:')
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.executescript(sql)
conn.commit()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [r[0] for r in cur.fetchall()]
print(f"Tables: {tables}")
for table in tables:
    cur.execute(f'SELECT * FROM "{table}" LIMIT 3')
    rows = cur.fetchall()
    if rows:
        print(f"\n  Table '{table}' columns: {list(rows[0].keys())}")
        for row in rows[:2]:
            print(f"  {dict(row)}")
    # Search for user_61
    cur.execute(f'PRAGMA table_info("{table}")')
    cols = [c[1].lower() for c in cur.fetchall()]
    if 'customer_reference' in cols or 'user_id' in cols:
        col = 'customer_reference' if 'customer_reference' in cols else 'user_id'
        cur.execute(f'SELECT * FROM "{table}" WHERE "{col}" = ?', (uid,))
        matched = cur.fetchall()
        if matched:
            print(f"  MATCHED by {col}={uid}: {[dict(r) for r in matched]}")
conn.close()

print("\n=== case_16/22: customer_data_read_replica_20260921.sql ===")
sql_path2 = Path("dataset/evidence/databases/customer_data_read_replica_20260921.sql")
sql2 = sql_path2.read_text(encoding='utf-8', errors='ignore')
conn2 = sqlite3.connect(':memory:')
conn2.row_factory = sqlite3.Row
cur2 = conn2.cursor()
cur2.executescript(sql2)
conn2.commit()
cur2.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables2 = [r[0] for r in cur2.fetchall()]
print(f"Tables: {tables2}")
uid16 = resolve('diya.k4436@outlook.com')
uid22 = resolve('seoyeon-han@gmail.com')
print(f"uid_16={uid16}, uid_22={uid22}")
for table in tables2:
    cur2.execute(f'SELECT * FROM "{table}" LIMIT 2')
    rows2 = cur2.fetchall()
    if rows2:
        print(f"\n  Table '{table}' cols: {list(rows2[0].keys())}")
        for row in rows2[:1]:
            print(f"  Sample: {dict(row)}")
    # Search for user_53, user_51
    cur2.execute(f'PRAGMA table_info("{table}")')
    cols2 = [c[1].lower() for c in cur2.fetchall()]
    for search_uid, label in [(uid16, 'uid_16'), (uid22, 'uid_22')]:
        for col_name in ['customer_reference', 'user_id', 'subject_reference']:
            if col_name in cols2:
                cur2.execute(f'SELECT * FROM "{table}" WHERE "{col_name}" = ?', (search_uid,))
                matched2 = cur2.fetchall()
                if matched2:
                    print(f"  MATCHED {label} by {col_name}: {[dict(r) for r in matched2]}")
conn2.close()
