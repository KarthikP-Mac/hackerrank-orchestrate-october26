"""Check SQL inventory for case_12 analytics_9914."""
import sqlite3
from pathlib import Path

sql = Path('dataset/evidence/databases/customer_data_inventory_20260817.sql').read_text(encoding='utf-8')
conn = sqlite3.connect(':memory:')
conn.row_factory = sqlite3.Row
cur = conn.cursor()
cur.executescript(sql)
conn.commit()
cur.execute('SELECT name FROM sqlite_master WHERE type="table"')
tables = [r[0] for r in cur.fetchall()]
print('Tables:', tables)
for table in tables:
    try:
        cur.execute(f'PRAGMA table_info("{table}")')
        cols = [c[1].lower() for c in cur.fetchall()]
        conds = []
        if 'email' in cols:
            conds.append(('email', 'minjun.kim@gmail.com'))
        if 'customer_reference' in cols:
            conds.append(('customer_reference', 'user_12'))
        for col, val in conds:
            cur.execute(f'SELECT * FROM "{table}" WHERE lower("{col}") = ?', (val.lower(),))
            rows = cur.fetchall()
            if rows:
                print(f'{table}: {[dict(r) for r in rows]}')
    except Exception as e:
        print(f'{table}: error {e}')
conn.close()
print()
# Check if analytics_9914 is in the inventory SQL by resource_id
sql2 = Path('dataset/evidence/databases/customer_data_inventory_20260817.sql').read_text(encoding='utf-8')
if 'analytics_9914' in sql2:
    print('analytics_9914 found in inventory SQL!')
    idx = sql2.find('analytics_9914')
    print(sql2[max(0, idx-50):idx+200])
else:
    print('analytics_9914 NOT in inventory SQL')
