"""Debug specific failing cases to understand what evidence they have."""
import csv, json, sys
sys.path.insert(0, 'code')

def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

import importlib.util
spec = importlib.util.spec_from_file_location("main", "code/main.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

rules = {r["data_category"]: r["required_action"] for r in load_csv("dataset/deletion_rules.csv")}
identities = {r["user_id"]: r for r in load_csv("dataset/user_identities.csv")}
audit_log = load_csv("dataset/user_audit_log.csv")
manifest = load_csv("dataset/evidence_files.csv")
activity_rows = load_csv("dataset/system_activity.csv")
sql_manifest = [e for e in manifest if e["file_path"].endswith(".sql")]

store = m.EvidenceStore(manifest)
store.build_index()

sample_cases = {r["case_id"]: r for r in load_csv("dataset/sample_deletion_requests.csv")}
sample_expected = {r["case_id"]: r for r in load_csv("dataset/sample_output.csv")}

# Diagnose specific cases
DEBUG_CASES = ["case_07", "case_09", "case_11", "case_25", "case_26", "case_27", "case_28"]

for cid in DEBUG_CASES:
    if cid not in sample_cases:
        continue
    case = sample_cases[cid]
    expected = sample_expected.get(cid, {})
    exp_status = expected.get("deletion_status", "?")
    
    uid, emails, phones = m.resolve_user(case["email"], identities, audit_log)
    print(f"\n=== {cid} === expected={exp_status}")
    print(f"  email={case['email']}, user_id={uid}")
    print(f"  all_emails={emails}")
    print(f"  text={case['request_text'][:100]}")
    print(f"  is_deletion={m.is_deletion_request(case['request_text'])}")
    
    recs = store.find_for_user(uid, emails, phones, case["audit_at"])
    sql_recs = m.search_sql(sql_manifest, emails, phones, uid, case["audit_at"])
    all_recs = recs + sql_recs
    
    print(f"  Evidence records: {len(recs)} json/log, {len(sql_recs)} sql")
    for rec in all_recs[:10]:
        action, cat, sys_id = m.classify(rec, rules)
        pres = m.is_present(rec)
        pii = m.has_pii(rec, emails)
        print(f"    [{rec['type']}] sys={sys_id} rid={rec['resource_id'][:30] if rec.get('resource_id') else 'None'} action={action} present={pres} pii={pii}")
