"""Deep dive remaining 6 failing sample cases."""
import csv, json, sys
sys.path.insert(0, 'code')

import importlib.util
spec = importlib.util.spec_from_file_location('main', 'code/main.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def load_csv(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

identities = {r['user_id']: r for r in load_csv('dataset/user_identities.csv')}
audit_log = load_csv('dataset/user_audit_log.csv')
manifest = load_csv('dataset/evidence_files.csv')
manifest_map = {r['file_id']: r for r in manifest}
activity_rows = load_csv('dataset/system_activity.csv')
rules = {r['data_category']: r['required_action'] for r in load_csv('dataset/deletion_rules.csv')}
sql_manifest = [e for e in manifest if e['file_path'].endswith('.sql')]

store = m.EvidenceStore(manifest)
store.build_index()

sample_cases = {r['case_id']: r for r in load_csv('dataset/sample_deletion_requests.csv')}
sample_expected = {r['case_id']: r for r in load_csv('dataset/sample_output.csv')}

FAILING = ['case_07', 'case_09', 'case_10', 'case_12', 'case_16', 'case_22']

from pathlib import Path
for cid in FAILING:
    case = sample_cases.get(cid)
    if not case:
        continue
    expected = sample_expected.get(cid, {})
    exp_status = expected.get('deletion_status', '?')
    exp_steps = json.loads(expected.get('steps_json', '[]'))
    
    uid, emails, phones = m.resolve_user(case['email'], identities, audit_log)
    print(f'\n=== {cid} === expected={exp_status}')
    print(f'  email={case["email"]}, uid={uid}')
    
    recs = store.find_for_user(uid, emails, phones, case['audit_at'])
    sql_recs = m.search_sql(sql_manifest, emails, phones, uid, case['audit_at'])
    print(f'  Evidence: {len(recs)} indexed + {len(sql_recs)} sql')
    
    # Show expected evidence_ids 
    ev_ids = set(s.get('evidence_id', '') for s in exp_steps if s.get('evidence_id'))
    print(f'  Expected evidence_ids: {ev_ids}')
    for eid in ev_ids:
        entry = manifest_map.get(eid, {})
        print(f'    {eid}: {entry.get("file_path","")} [{entry.get("captured_at","")}]')
    
    # Check activity rows for this user
    user_activity = []
    for row in activity_rows:
        det = (row.get('details') or '').lower()
        for em in emails:
            if em.lower() in det:
                user_activity.append(row)
                break
        else:
            if uid and uid.lower() in det:
                user_activity.append(row)
    print(f'  Activity rows: {len(user_activity)}')
    if user_activity:
        for a in user_activity[:3]:
            print(f'    {a.get("event_type","")} | {a.get("resource_id","")} | {(a.get("details") or "")[:60]}')
