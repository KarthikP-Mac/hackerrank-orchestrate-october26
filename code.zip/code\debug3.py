"""Check what evidence files might relate to specific failing cases."""
import csv, json

def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

identities = {r["user_id"]: r for r in load_csv("dataset/user_identities.csv")}
audit_log = load_csv("dataset/user_audit_log.csv")
manifest = load_csv("dataset/evidence_files.csv")
sample_cases = {r["case_id"]: r for r in load_csv("dataset/sample_deletion_requests.csv")}

# Cases with zero evidence
INVESTIGATE = ["case_07", "case_09", "case_10", "case_11", "case_12", "case_13", 
               "case_14", "case_15", "case_16", "case_17", "case_19", "case_22"]

def resolve_email_to_uid(email, identities, audit_log):
    email_norm = email.strip().lower()
    for uid, row in identities.items():
        if row.get("email","").strip().lower() == email_norm:
            return uid
    for entry in audit_log:
        if entry.get("field_name") == "email":
            if (entry.get("old_value") or "").strip().lower() == email_norm:
                return entry["user_id"]
            if (entry.get("new_value") or "").strip().lower() == email_norm:
                return entry["user_id"]
    return None

print("=== File types in manifest ===")
from collections import Counter
ext_counter = Counter(e["file_path"].rsplit(".", 1)[-1] for e in manifest)
print(ext_counter)

print("\n=== Evidence paths with case emails ===")
for cid in INVESTIGATE[:5]:
    case = sample_cases.get(cid)
    if not case:
        continue
    email = case["email"]
    uid = resolve_email_to_uid(email, identities, audit_log)
    print(f"\n{cid}: email={email} uid={uid}")
    # Search evidence files that might mention this user
    for entry in manifest:
        fp = entry["file_path"]
        fid = entry["file_id"]
        # Check if any PDFs or images exist with evidence for this case
        if any(x in fp.lower() for x in ["pdf", "png", "image", "doc"]):
            pass  # we'll check content
    # Look in evidence directory
    from pathlib import Path
    ev_dir = Path("dataset/evidence")
    for fp in ev_dir.rglob("*"):
        if fp.is_file():
            ext = fp.suffix.lower()
            if ext in (".pdf", ".png", ".jpg", ".jpeg"):
                continue
            try:
                content = fp.read_text(encoding="utf-8", errors="ignore")
                if email.lower() in content.lower() or (uid and uid.lower() in content.lower()):
                    print(f"  FOUND in {fp.relative_to('dataset')}: ext={ext}")
            except Exception:
                pass

print("\n=== Sample expected output for failing cases ===")
sample_out = {r["case_id"]: r for r in load_csv("dataset/sample_output.csv")}
for cid in ["case_07", "case_11", "case_15", "case_17"]:
    expected = sample_out.get(cid, {})
    steps = json.loads(expected.get("steps_json", "[]"))
    print(f"\n{cid} expected={expected.get('deletion_status')}:")
    for s in steps[:5]:
        print(f"  {s}")
