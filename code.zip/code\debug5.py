"""Debug remaining failing cases."""
import csv, json, sys
sys.path.insert(0, 'code')

def load_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

import importlib.util
spec = importlib.util.spec_from_file_location("main", "code/main.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

rules = {r["data_category"]: r["required_action"] for r in load_csv("dataset/deletion_rules.csv")}
identities = {r["user_id"]: r for r in load_csv("dataset/user_identities.csv")}
audit_log = load_csv("dataset/user_audit_log.csv")
manifest = load_csv("dataset/evidence_files.csv")
activity_rows = load_csv("dataset/system_activity.csv")

store = m.EvidenceStore(manifest)
store.build_index()

sample_cases = {r["case_id"]: r for r in load_csv("dataset/sample_deletion_requests.csv")}
sample_expected = {r["case_id"]: r for r in load_csv("dataset/sample_output.csv")}

for cid in ["case_15", "case_17", "case_09", "case_10"]:
    case = sample_cases.get(cid)
    if not case:
        continue
    expected = sample_expected.get(cid, {})
    exp_status = expected.get("deletion_status", "?")
    
    uid, emails, phones = m.resolve_user(case["email"], identities, audit_log)
    print(f"\n=== {cid} === expected={exp_status}")
    print(f"  email={case['email']}, user_id={uid}")
    
    recs = store.find_for_user(uid, emails, phones, case["audit_at"])
    sql_manifest = [e for e in manifest if e["file_path"].endswith(".sql")]
    sql_recs = m.search_sql(sql_manifest, emails, phones, uid, case["audit_at"])
    all_recs = recs + sql_recs
    
    print(f"  Evidence records: {len(recs)} json/log, {len(sql_recs)} sql")
    for rec in all_recs:
        action, cat, sys_id = m.classify(rec, rules)
        pres = m.is_present(rec)
        pii = m.has_pii(rec, emails)
        print(f"    [{rec['type']}] sys={sys_id} rid={rec.get('resource_id','')[:30]} action={action} present={pres} pii={pii}")
    
    # Show expected steps
    exp_steps = json.loads(expected.get("steps_json", "[]"))
    print(f"  Expected steps ({len(exp_steps)}):")
    for s in exp_steps[:4]:
        print(f"    {s}")
