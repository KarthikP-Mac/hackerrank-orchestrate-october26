"""Debug case_15 and case_17 evidence lookup."""
import sys, csv
sys.path.insert(0, 'code')

import importlib.util
spec = importlib.util.spec_from_file_location('main', 'code/main.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def load_csv(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

identities = {r['user_id']: r for r in load_csv('dataset/user_identities.csv')}
audit_log = load_csv('dataset/user_audit_log.csv')
manifest = load_csv('dataset/evidence_files.csv')
store = m.EvidenceStore(manifest)
store.build_index()

sample_cases = {r['case_id']: r for r in load_csv('dataset/sample_deletion_requests.csv')}

for cid in ['case_15', 'case_17']:
    case = sample_cases[cid]
    uid, emails, phones = m.resolve_user(case['email'], identities, audit_log)
    print(f'\n{cid}: email={case["email"]} uid={uid} emails={emails}')
    recs = store.find_for_user(uid, emails, phones, case['audit_at'])
    print(f'  Records found: {len(recs)}')
    for rec in recs:
        print(f'  [{rec["type"]}] sys={rec["system"]} rid={rec.get("resource_id","")} enabled={rec.get("enabled")} restore_allowed={rec.get("restore_allowed")}')

# Check email index for lucia-torres
print('\nlucia-torres in email_index:', 'lucia-torres@gmail.com' in store._email_index)
print('leonie.g9352 in email_index:', 'leonie.g9352@outlook.com' in store._email_index)
if 'lucia-torres@gmail.com' in store._email_index:
    for r in store._email_index['lucia-torres@gmail.com']:
        print(f'  lucia entry: type={r["type"]} sys={r["system"]} rid={r.get("resource_id","")}')
if 'leonie.g9352@outlook.com' in store._email_index:
    for r in store._email_index['leonie.g9352@outlook.com']:
        print(f'  leonie entry: type={r["type"]} sys={r["system"]} rid={r.get("resource_id","")}')
