"""Debug case_10 support_replica log."""
import sys, csv
sys.path.insert(0, 'code')

import importlib.util
spec = importlib.util.spec_from_file_location('main', 'code/main.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def load_csv(p):
    with open(p, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

identities = {r['user_id']: r for r in load_csv('dataset/user_identities.csv')}
audit_log = load_csv('dataset/user_audit_log.csv')
manifest = load_csv('dataset/evidence_files.csv')
manifest_map = {r['file_id']: r for r in manifest}
rules = {r['data_category']: r['required_action'] for r in load_csv('dataset/deletion_rules.csv')}

store = m.EvidenceStore(manifest)
store.build_index()

# Check email index for nadia
email = 'nadia.ionescu@yahoo.com'
print(f"'{email}' in email_index:", email in store._email_index)
if email in store._email_index:
    for r in store._email_index[email]:
        print(f"  [{r['type']}] sys={r['system']} rid={r.get('resource_id','')} fid={r['file_id']} rows={r.get('rows','?')}")

# Manually parse the support_replica.log
print("\nManual parse of support_replica.log:")
content = open('dataset/evidence/logs/support_replica.log', encoding='utf-8', errors='ignore').read()
print("Is handover?", '| account_service |' in content or '| search_service |' in content or 'SHIFT HANDOVER' in content)

import re
# Check trace_id first pass
trace_context = {}
for line in content.split('\n'):
    if 'trace_id=' not in line:
        continue
    tf = {m2.group(1): m2.group(2) for m2 in re.finditer(r'(\w+)=([^\s]+)', line)}
    tq = {m2.group(1): m2.group(2) for m2 in re.finditer(r'(\w+)="([^"]+)"', line)}
    tf.update(tq)
    tid = tf.get('trace_id', '')
    t_emails = []
    for k in ('lookup_key', 'subject_key', 'scan_key', 'match_key', 'customer_email', 'requester_email', 'correlation_key', 'matched_value'):
        v = tf.get(k, '')
        if v and '@' in v:
            t_emails.append(v.strip().lower())
    if t_emails:
        trace_context[tid] = t_emails
        print(f"  Trace {tid}: emails={t_emails}")
print(f"  trace_context: {trace_context}")
