import csv, json
with open('output.csv', newline='', encoding='utf-8') as f:
    rows = list(csv.DictReader(f))

complete = [r for r in rows if r['deletion_status'] == 'COMPLETE']
incomplete = [r for r in rows if r['deletion_status'] == 'INCOMPLETE']
na = [r for r in rows if r['deletion_status'] == 'NOT_APPLICABLE']

complete_empty = [r for r in complete if json.loads(r['steps_json']) == []]
complete_steps = [r for r in complete if json.loads(r['steps_json']) != []]

print(f"Total: {len(rows)}")
print(f"COMPLETE: {len(complete)} ({len(complete_steps)} with steps, {len(complete_empty)} empty)")
print(f"INCOMPLETE: {len(incomplete)}")
print(f"NOT_APPLICABLE: {len(na)}")

# Check step counts for INCOMPLETE
step_counts = [len(json.loads(r['steps_json'])) for r in incomplete]
avg_steps = sum(step_counts) / len(step_counts) if step_counts else 0
print(f"\nINCOMPLETE avg steps: {avg_steps:.1f}")
print(f"INCOMPLETE with 0 steps: {sum(1 for s in step_counts if s == 0)}")
